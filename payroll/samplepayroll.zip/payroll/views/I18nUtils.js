sap.ui.define([], function () {
	"use strict";
	return sap.ui.base.Object.extend("sap.ui.hcp.ext.payroll.views.I18nUtils", {
		
		/* A convenience formatter that assumes at least one mandatory (first) argument - a parameterized text.
		 * Next arguments, if any, would be the values that will be used to replace the placeholders in the 
		 * parameterized text. The parameters are 0 to n indexes in curly braces ({}), corresponding to the 
		 * arguments order that will replace them. */
		i18nParameterizedTextFormatter: function(parameterizedText) {
	    	var finalText = parameterizedText;
		    for (var i = 1; i < arguments.length; i++) {
		        var argument = arguments[i];
		        var placeholder = '{' + (i - 1) + '}';
		        finalText = finalText.replace(placeholder, arguments[i]);
		    }
		    return finalText;
		},
	
		/* Custom logic for using the model value bound to a FormELement label text as key to retrieve its i81n value from
		 * a resource bundle. Unlike the labels in the header some property names are not static but are dynamically fetched
		 * from the backend. Therefore we cannot directly encode the databinding to a resource i18n bundle in the XMLView but
		 * need to handle this manually.
		 * The algorithm below assumes that keys on resource bundle files reflect the names of the properties in the 
		 * corresponding entity provided from the model. In this way the final label text is set in two steps. First, the label
		 * text is set by the label binding to a model property. This is the key that is used on next step by this algorithm
		 * to locate a corresponding localized text in the resource bundles and finally set it as label text. */
		seti18nLabels: function(oFormContainerControl, resourceBundle){
			var formElements = oFormContainerControl.getFormElements();
			for (var i = 0; i < formElements.length; i++){
				var bindingInfos = formElements[i].mBindingInfos;
				if(bindingInfos && bindingInfos.label && bindingInfos.label.binding){
					var rbKey = formElements[i].mBindingInfos.label.binding.getValue();
					if(rbKey){
						var rbText = resourceBundle.getText(rbKey);
						formElements[i].setLabel(rbText);					
					}					
				}				
			}
		}
	});
});