sap.ui.define([
	"sap/ui/hcp/ext/payroll/views/BaseController",
	"sap/ui/core/format/DateFormat",
	"sap/ui/hcp/ext/payroll/views/I18nUtils"
], function (BaseController) {
	"use strict";
	return BaseController.extend("sap.ui.hcp.ext.payroll.views.Details", {
		
		onInit : function() {
			var oModel = sap.ui.getCore().getModel();
			oModel.attachRequestCompleted(this._handleModelChange, this);
			this.getView().setModel(oModel);
			this.getRouter().getRoute("details").attachPatternMatched(this._routePatternMatched, this);
			this.i18nUtils = new sap.ui.hcp.ext.payroll.views.I18nUtils();
			
			/* Setup currency formatter*/
			var sBrowserLocale = sap.ui.getCore().getConfiguration().getLanguage();
		    var oLocale = new sap.ui.core.Locale(sBrowserLocale);
		    var oLocaleData = new sap.ui.core.LocaleData(oLocale);		
			this.currencyFormatter = new sap.ui.model.type.Currency({
					showMeasure: true ,
				    currencyCode: false
				}, oLocaleData.mData.currencyFormat);
		},
		
		/* Handle requests to PayrollItemDetails navigation property of an identified PayrollHeader OData Entity */
		_handleModelChange: function(evt){
			var sTargetEntityNameMatchers = evt.getParameter("url").match(/[^\/][\w]+(?=\?)/gm); 
			if(sTargetEntityNameMatchers && sTargetEntityNameMatchers[0] === "PayrollItemDetails"){
				/* Get the resource bundle */
				var oBundle = this.getView().getModel("i18n").getResourceBundle();
				if(!oBundle){
					var e = new Error();
					e.message = "Resource bundle not found in model 'i18n'";
					throw e;
				}
				/* localize labels in the forms of the view */
				var earningsControl = this.getView().byId("fc1");
				this.i18nUtils.seti18nLabels(earningsControl, oBundle);
				var deductionsControl = this.getView().byId("fc2");
				this.i18nUtils.seti18nLabels(deductionsControl, oBundle);
			}
		},
		
		_routePatternMatched: function(evt){
			var sName = evt.getParameter("name");
			if (sName !== "details") {
				return;
			}
			
			var sId = evt.getParameter("arguments").id;
			//simple client-side validation: we accept only numeric IDs
			if(isNaN(sId)){
				this.getRouter().getTargets().display("notfound");
				return;
			}	
			
			var sPath = "/PayrollHeaders('"+sId+"')" ;

			var oModel = sap.ui.getCore().getModel();
			this.getView().bindElement(sPath);
			
			var oData = oModel.getProperty(sPath);
			//if there is no data the model has to request new data
			if (!oData) {
				this.getView().getElementBinding().attachEventOnce("dataReceived", jQuery.proxy(function() {
					var oModel = this.getView().getModel();
					var oData = oModel.getData(sPath);
					if (!oData) {
						//display the "notFound" target without changing the hash
						this.getRouter().getTargets().display("notfound");
					}
				}, this));
			}
		},
		

		currencyTextI18NFormatter : function(i18nParameterizedText, fValue, sCurrencyCode) {
			return this.i18nUtils.i18nParameterizedTextFormatter(i18nParameterizedText, 
					this.currencyFormatter.formatValue([fValue, sCurrencyCode ], "string"));
		},
		
		pageTitleI18NFormatter: function(i18nParameterizedText, sEmployeeName, oDate){
			return this.i18nUtils.i18nParameterizedTextFormatter(i18nParameterizedText, sEmployeeName, oDate);
		}	
	});
});