sap.ui.define([
	"sap/ui/hcp/ext/payroll/views/BaseController"
], function (BaseController) {
	"use strict";
	return BaseController.extend("sap.ui.hcp.ext.payroll.views.NotFound", {
		
		onInit: function () {
			var oRouter, oTarget;
			oRouter = this.getRouter();
			oTarget = oRouter.getTarget("notfound");
		}
	
	});
});