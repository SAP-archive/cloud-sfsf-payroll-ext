jQuery.sap.declare('sap.ui.hcp.ext.payroll.Component');
jQuery.sap.require('sap.ui.core.routing.History');
jQuery.sap.require('sap.m.routing.RouteMatchedHandler');
sap.ui.core.UIComponent.extend('sap.ui.hcp.ext.payroll.Component', {
    metadata: {
        name: 'Payroll',
        version: '1.0',
        includes: ['css/theme.css'],
        dependencies: {
            libs: [
                'sap.m',
                'sap.ui.layout',
                'sap.ui.commons',
                'sap.suite.ui.commons'
            ]
        },
        rootView: 'sap.ui.hcp.ext.payroll.App',
        config: {
            resourceBundle: 'i18n/i18n.properties',
            serviceConfig: {
                name: 'com.sap.hana.cloud.sample.payroll',
                serviceUrl: '/destinations/3rd_party_sample_payroll/OData.svc/'
            }
        },
        routing: {
            config: {
            	routerClass: "sap.m.routing.Router",
                viewType: 'XML',
                viewPath: 'sap.ui.hcp.ext.payroll.views',
	    		controlId: "AppContainter",
	    	    controlAggregation: "pages",
                bypassed: {
                   "target": "notfound"
                }
            },
            routes: [{
	                	name: 'home',
	                    pattern: '',
	                    target: 'master'
                   	},{
                   		name: 'details',
	                    pattern: '{id}',
	                    target: 'details'
                   	}],
             targets: {
            	 master: {
            		 viewName: "Master",
            		 viewLevel: 1
            	 },
            	 notfound: {
            		 viewName: "NotFound",
            		 transition: "show"
            	 },
            	 details: {
            		 viewName: "Details",
            	     viewLevel : 2
            	 }
             }
        }
    },
    
    init: function () {
        sap.ui.core.UIComponent.prototype.init.apply(this, arguments);
        var mConfig = this.getMetadata().getConfig();
        var rootPath = jQuery.sap.getModulePath('sap.ui.hcp.ext.payroll');
        var i18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl: [
                rootPath,
                mConfig.resourceBundle
            ].join('/')
        });
        this.setModel(i18nModel, 'i18n');
        //non-subscription deployment model for ui (local)
        if(window.location.hostname.indexOf(".dispatcher.") < 0){
        	mConfig.serviceConfig.serviceUrl = "/OData.svc/";
        }
        var oModel = new sap.ui.model.odata.ODataModel(mConfig.serviceConfig.serviceUrl, true);
        sap.ui.getCore().setModel(oModel);
        var router = this.getRouter();
        this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
        router.initialize();
    },
    
    destroy: function () {
        if (this.routeHandler) {
            this.routeHandler.destroy();
        }
        this.getModel('i18n').destroy();
        sap.ui.getCore().getModel().destroy();
        sap.ui.core.UIComponent.destroy.apply(this, arguments);
    }
});