sap.ui.define([
	"sap/ui/hcp/ext/payroll/views/BaseController",
	"sap/ui/model/type/Currency",
	"sap/ui/hcp/ext/payroll/views/I18nUtils"
], function (BaseController) {
	"use strict";
	return BaseController.extend("sap.ui.hcp.ext.payroll.views.Master", {

		onInit : function() {
			var oModel = sap.ui.getCore().getModel();		
			oModel.attachRequestCompleted(this._handleModelChange, this);
			this.getView().byId("list").setModel(oModel);
			this.i18nUtils = new sap.ui.hcp.ext.payroll.views.I18nUtils(); 
		},
		
		_handleModelChange: function(){
			var oList = this.getView().byId("list");
			this._setupChart(oList);
			this._setupPayslipsList(oList);
		},
		
		_setupPayslipsList: function(oList){
			var displayListItems = oList.getItems();
			for(var i=0;i<displayListItems.length;i++){
				var ctx = displayListItems[i].getBindingContext().getObject();
				if(ctx.Pending)
					displayListItems[i].addStyleClass("pending");
			}			
		},
		
		_setupChart: function(oList){
			var headers = oList.getModel().oData;
			var earningsOverallTotal = 0, deductionsOverallTotal = 0, currencyCode;
			
			/* Calculate the total earnings and deductions, and the currency code */
			if(headers){
				for (var property in headers) {
				    if (headers.hasOwnProperty(property)) {
				    	if(headers[property].TotalEarnings){
				    		earningsOverallTotal += parseFloat(headers[property].TotalEarnings);
				    	}
				    	if(headers[property].TotalDeductions){
				    		deductionsOverallTotal += parseFloat(headers[property].TotalDeductions);
				    	}
				    	if(!currencyCode && headers[property].CurrencyCode){
				    		currencyCode = headers[property].CurrencyCode;
				    	}
				    }
				}
			}
			
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			if(!oBundle){
				var e = new Error();
				e.message = "Resource bundle not found in model 'i18n'";
				throw e;
			}
			
			/*format chart tooltip text*/
			var sBrowserLocale = sap.ui.getCore().getConfiguration().getLanguage();
		    var oLocale = new sap.ui.core.Locale(sBrowserLocale);
		    var oLocaleData = new sap.ui.core.LocaleData(oLocale);
			var currencyFormatter = new sap.ui.model.type.Currency({
				showMeasure: true ,
			    currencyCode: false,
			    maxFractionDigits: 2
			}, oLocaleData.mData.currencyFormat);
			var tooltipText = oBundle.getText("Chart-tooltip",[
												 	currencyFormatter.formatValue([earningsOverallTotal, currencyCode], "string"),
			                                        currencyFormatter.formatValue([deductionsOverallTotal, currencyCode], "string")
			                                  ]);
			/* Set model to chart */
			this.getView().byId("chart").setModel(new sap.ui.model.json.JSONModel({
				 data: [{
				 			title: oBundle.getText("Earnings"), 
				 			value: earningsOverallTotal, 
				 			color: sap.suite.ui.commons.InfoTileValueColor.Good, 
				 			displayValue:earningsOverallTotal 
				 	
						},
						{ 
			            	title: oBundle.getText("Deductions"), 
			            	value: deductionsOverallTotal, 
			            	color: sap.suite.ui.commons.InfoTileValueColor.Critical, 
			            	displayValue:deductionsOverallTotal 
			            }],
			     scale: currencyCode,
			     tooltip: tooltipText			     
				}));
		},
		
		onSelect: function(evt){
			var oBindContext = evt.getParameter("listItem").getBindingContext();
			var oModel = oBindContext.getModel();
			var sId = oModel.getProperty(oBindContext.getPath()).Id;
			this.getRouter().navTo("details", {id: sId}, true);
		},
		
		displayListItemI18NTextFormatter: function(i18nParameterizedText, oDate, bIsPending, pendingText) {
			var sPendingText = bIsPending? pendingText:'';
			return this.i18nUtils.i18nParameterizedTextFormatter(i18nParameterizedText, oDate, sPendingText);
		}
	});
});