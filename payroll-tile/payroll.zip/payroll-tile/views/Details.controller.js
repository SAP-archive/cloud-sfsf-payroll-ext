jQuery.sap.require("sap.ui.core.format.DateFormat");
sap.ui.controller("sap.ui.hcp.ext.payroll.views.Details", {

	onInit : function() {
		var oModel = sap.ui.getCore().getModel();
		oModel.attachRequestCompleted(this.handleModelChange, this);
		this.getView().setModel(oModel);
		this.router = sap.ui.core.UIComponent.getRouterFor(this);
		this.router.getRoute("details").attachPatternMatched(this._routePatternMatched, this);
	},
	
	handleModelChange: function(evt){
		var sTargetEntityNameMatchers = evt.getParameter('url').match(/[^\/][\w]+(?=\?)/gm);
		if(sTargetEntityNameMatchers && "PayrollItemDetails" == sTargetEntityNameMatchers[0]){
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			if(!oBundle)
				throw "Resource bundle not found in model 'i18n'";
			var earningsControl = this.getView().byId('fc1');
			this._seti18nLabels(earningsControl, oBundle);
			var deductionsControl = this.getView().byId('fc2');
			this._seti18nLabels(deductionsControl, oBundle);
		}
	},
	
	/* Custom logic for using the model value bound to a FormELement label text as key to retrieve its i81n value from
	 * a resource bundle. Unlike the labels in the header some property names are not static but are dynamically fetched
	 * from the backend. therefore we cannot directly encode the databinding to a resource i18n bundle in the XMLView but
	 * need to handle this manually.*/
	_seti18nLabels: function(oFormContainerControl, resourceBundle){
		var formElements = oFormContainerControl.getFormElements();
		for (var i = 0; i < formElements.length; i++){
			var bindingInfos = formElements[i].mBindingInfos;
			if(bindingInfos && bindingInfos.label && bindingInfos.label.binding){
				var rbKey = formElements[i].mBindingInfos.label.binding.getValue();
				if(rbKey){
					var rbText = resourceBundle.getText(rbKey);
					formElements[i].setLabel(rbText);					
				}					
			}				
		}
	},
	
	onNavBack : function() {
		this.router.navTo("");
	},
	
	_routePatternMatched: function(evt){
		var sId = evt.getParameter("arguments").id;
		var sPath = "/PayrollHeaders('"+sId+"')" ;

		var oModel = sap.ui.getCore().getModel();
		var oData = oModel.getProperty(sPath);
		this.getView().bindElement(sPath);
		
		//if there is no data the model has to request new data
		var that = this;
		if (!oData) {
			this.getView().getElementBinding().attachEventOnce("dataReceived", function() {
				that._checkIfDataAvailable(sPath, sId);
			});
		}
	},
	
	_checkIfDataAvailable: function(sPath, sId) {
		var oModel = this.getView().getModel();
		var oData = oModel.getData(sPath);
		// show not found page
		if (!oData) {
			this.router.getTargets().display("", sId);//TODO: implement Not Found view
		}
	},
	
	dateFormatter: function(oDate) {
		var oDate = (oDate instanceof Date) ? oDate : new Date(oDate);
		var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM-yyyy" });
        return dateFormat.format(oDate);
	}
});