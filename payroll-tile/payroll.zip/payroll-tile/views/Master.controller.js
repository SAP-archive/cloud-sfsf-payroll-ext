sap.ui.controller("sap.ui.hcp.ext.payroll.views.Master", {

	onInit : function() {
		var oModel = sap.ui.getCore().getModel();
		
		oModel.attachRequestCompleted(jQuery.proxy(function() {
			var headers = this.getView().byId("list").getModel().oData;
			var earningsOverallTotal = 0, deductionsOverallTotal = 0;
			if(headers){
				for (var property in headers) {
				    if (headers.hasOwnProperty(property)) {
				    	if(headers[property].TotalEarnings)
				    		earningsOverallTotal += parseFloat(headers[property].TotalEarnings);
				    	if(headers[property].TotalDeductions)
				    		deductionsOverallTotal += parseFloat(headers[property].TotalDeductions);
				    }
				}
			}
			
			var oBundle = this.getView().getModel("i18n").getResourceBundle();
			if(!oBundle)
				throw "Resource bundle not found in model 'i18n'";
			var chartScale = "EUR";
			this.getView().byId('chart').setModel(new sap.ui.model.json.JSONModel({
				 data: [{ title: oBundle.getText("Earnings"), value: earningsOverallTotal, color: sap.suite.ui.commons.InfoTileValueColor.Good, displayValue:earningsOverallTotal },
			            { title: oBundle.getText("Deductions"), value: deductionsOverallTotal, color: sap.suite.ui.commons.InfoTileValueColor.Critical, displayValue:deductionsOverallTotal }],
			     scale:chartScale,
			     tooltip: oBundle.getText("chart-tooltip-prefix") +
			     		  "\n" +  oBundle.getText("Earnings") + ": " + earningsOverallTotal + " " + chartScale +
			     		  "\n" +  oBundle.getText("Deductions") + ": " + deductionsOverallTotal + " " + chartScale			     
				}));
		}, this));
		
		this.getView().byId("list").setModel(oModel);
		
	},
	
	onSelect: function(evt){
		var router = sap.ui.core.UIComponent.getRouterFor(this);
		var oBindContext = evt.getParameter('listItem').getBindingContext();
		var oModel = oBindContext.getModel();
		var sId = oModel.getProperty(oBindContext.getPath()).Id;
		router.navTo("details", {id: sId}, true);
	},
	
	dateFormatter: function(oDate) {
		var oDate = (oDate instanceof Date) ? oDate : new Date(oDate);
		var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({pattern : "MM-yyyy" });
        return dateFormat.format(oDate);
	}
	
});