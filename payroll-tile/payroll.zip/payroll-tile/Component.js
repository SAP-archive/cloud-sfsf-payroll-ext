jQuery.sap.declare("sap.ui.hcp.ext.payroll.Component");
jQuery.sap.require("sap.ui.core.routing.History");
jQuery.sap.require("sap.m.routing.RouteMatchedHandler");

sap.ui.core.UIComponent.extend("sap.ui.hcp.ext.payroll.Component", {
	metadata : {
		name : "Payroll",
		version : "1.0",
		includes : [],
		dependencies : {
			libs : ["sap.m", "sap.ui.layout", "sap.ui.commons", "sap.suite.ui.commons"]
		},

		rootView : "sap.ui.hcp.ext.payroll.App",
		
		config : {
			resourceBundle : "i18n/messageBundle.properties"
		},

		routing : {
			config : {
				viewType : "XML",
				viewPath : "sap.ui.hcp.ext.payroll.views",
				targetAggregation : "pages",
				clearTarget : false
			},
			routes : [
				{
					pattern : "",
					name : "main",
					view : "Master",
					targetAggregation : "pages",
					targetControl : "AppContainter",
					subroutes : [
						{
							pattern : "{id}",
							name : "details",
							view : "Details"
						}
					]
				}
			]
		}
	},

	init : function() {
				
		sap.ui.core.UIComponent.prototype.init.apply(this, arguments);

		var mConfig = this.getMetadata().getConfig();
        var rootPath = jQuery.sap.getModulePath("sap.ui.hcp.ext.payroll");

        // set i18n model
        var i18nModel = new sap.ui.model.resource.ResourceModel({
            bundleUrl : [rootPath, mConfig.resourceBundle].join("/")
        });
        this.setModel(i18nModel, "i18n");
		
		// Create and set domain model to the component
		var oModel = new sap.ui.model.odata.ODataModel("OData.svc/", true);	
		sap.ui.getCore().setModel(oModel);
		
		var router = this.getRouter();
		this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
		router.initialize();
	},
	
	destroy: function(){
		if(this.routeHandler){
			this.routeHandler.destroy();
		}
		sap.ui.core.UIComponent.destroy.apply(this,arguments);
	}
});

